//
//  AICContext.h
//  Analytics
//
//  Created by Tony Xiao on 9/19/16.
//  Copyright © 2016 Segment. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AICIntegration.h"

typedef NS_ENUM(NSInteger, AICEventType) {
    // Should not happen, but default state
    AICEventTypeUndefined,
    // Core Tracking Methods
    AICEventTypeIdentify,
    AICEventTypeTrack,
    AICEventTypeScreen,
    AICEventTypeGroup,
    AICEventTypeAlias,

    // General utility
    AICEventTypeReset,
    AICEventTypeFlush,

    // Remote Notification
    AICEventTypeReceivedRemoteNotification,
    AICEventTypeFailedToRegisterForRemoteNotifications,
    AICEventTypeRegisteredForRemoteNotifications,
    AICEventTypeHandleActionWithForRemoteNotification,

    // Application Lifecycle
    AICEventTypeApplicationLifecycle,
    //    DidFinishLaunching,
    //    AICEventTypeApplicationDidEnterBackground,
    //    AICEventTypeApplicationWillEnterForeground,
    //    AICEventTypeApplicationWillTerminate,
    //    AICEventTypeApplicationWillResignActive,
    //    AICEventTypeApplicationDidBecomeActive,

    // Misc.
    AICEventTypeContinueUserActivity,
    AICEventTypeOpenURL,

} NS_SWIFT_NAME(EventType);

@class Aicactus;
@protocol AICMutableContext;


NS_SWIFT_NAME(Context)
@interface AICContext : NSObject <NSCopying>

// Loopback reference to the top level Aicactus object.
// Not sure if it's a good idea to keep this around in the context.
// since we don't really want people to use it due to the circular
// reference and logic (Thus prefixing with underscore). But
// Right now it is required for integrations to work so I guess we'll leave it in.
@property (nonatomic, readonly, nonnull) Aicactus *_analytics;
@property (nonatomic, readonly) AICEventType eventType;

@property (nonatomic, readonly, nullable) NSError *error;
@property (nonatomic, readonly, nullable) AICPayload *payload;
@property (nonatomic, readonly) BOOL debug;

- (instancetype _Nonnull)initWithAnalytics:(Aicactus *_Nonnull)analytics;

- (AICContext *_Nonnull)modify:(void (^_Nonnull)(id<AICMutableContext> _Nonnull ctx))modify;

@end

@protocol AICMutableContext <NSObject>

@property (nonatomic) AICEventType eventType;
@property (nonatomic, nullable) AICPayload *payload;
@property (nonatomic, nullable) NSError *error;
@property (nonatomic) BOOL debug;

@end
