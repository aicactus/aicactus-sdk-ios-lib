#import <Foundation/Foundation.h>
#import "AICIntegrationFactory.h"
#import "AICHTTPClient.h"
#import "AICStorage.h"

NS_ASSUME_NONNULL_BEGIN


NS_SWIFT_NAME(SegmentIntegrationFactory)
@interface AICSegmentIntegrationFactory : NSObject <AICIntegrationFactory>

@property (nonatomic, strong) AICHTTPClient *client;
@property (nonatomic, strong) id<AICStorage> userDefaultsStorage;
@property (nonatomic, strong) id<AICStorage> fileStorage;

- (instancetype)initWithHTTPClient:(AICHTTPClient *)client fileStorage:(id<AICStorage>)fileStorage userDefaultsStorage:(id<AICStorage>)userDefaultsStorage;

@end

NS_ASSUME_NONNULL_END
