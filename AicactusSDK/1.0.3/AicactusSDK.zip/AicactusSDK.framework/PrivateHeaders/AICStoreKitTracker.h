#import <Foundation/Foundation.h>
#import <StoreKit/StoreKit.h>
#import "Aicactus.h"

NS_ASSUME_NONNULL_BEGIN


NS_SWIFT_NAME(StoreKitTracker)
@interface AICStoreKitTracker : NSObject <SKPaymentTransactionObserver, SKProductsRequestDelegate>

+ (instancetype)trackTransactionsForAnalytics:(Aicactus *)analytics;

@end

NS_ASSUME_NONNULL_END
