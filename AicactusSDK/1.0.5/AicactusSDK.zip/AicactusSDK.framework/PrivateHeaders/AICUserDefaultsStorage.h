//
//  AICUserDefaultsStorage.h
//  Analytics
//
//  Created on 8/24/16.
//  Copyright © 2016 Aicactus All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AICStorage.h"


NS_SWIFT_NAME(UserDefaultsStorage)
@interface AICUserDefaultsStorage : NSObject <AICStorage>

@property (nonatomic, strong, nullable) id<AICCrypto> crypto;
@property (nonnull, nonatomic, readonly) NSUserDefaults *defaults;
@property (nullable, nonatomic, readonly) NSString *namespacePrefix;

- (instancetype _Nonnull)initWithDefaults:(NSUserDefaults *_Nonnull)defaults namespacePrefix:(NSString *_Nullable)namespacePrefix crypto:(id<AICCrypto> _Nullable)crypto;

@end
