//
//  AICState.h
//  Analytics
//
//  Created on 6/9/20.
//  Copyright © 2020 Aicactus All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class AicactusConfiguration;

@interface AICUserInfo: NSObject
@property (nonatomic, strong) NSString *anonymousId;
@property (nonatomic, strong, nullable) NSString *userId;
@property (nonatomic, strong, nullable) NSDictionary *traits;
@end

@interface AICPayloadContext: NSObject
@property (nonatomic, readonly) NSDictionary *payload;
@property (nonatomic, strong, nullable) NSDictionary *referrer;
@property (nonatomic, strong, nullable) NSString *deviceToken;

- (void)updateStaticContext;

@end



@interface AICState : NSObject

@property (nonatomic, readonly) AICUserInfo *userInfo;
@property (nonatomic, readonly) AICPayloadContext *context;

@property (nonatomic, strong, nullable) AicactusConfiguration *configuration;

+ (instancetype)sharedInstance;
- (instancetype)init __unavailable;

- (void)setUserInfo:(AICUserInfo *)userInfo;
@end

NS_ASSUME_NONNULL_END
