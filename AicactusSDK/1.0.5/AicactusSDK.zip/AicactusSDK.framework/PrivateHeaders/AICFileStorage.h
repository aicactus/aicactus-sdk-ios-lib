//
//  AICFileStorage.h
//  Analytics
//
//  Copyright © 2016 Aicactus All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AICStorage.h"


NS_SWIFT_NAME(FileStorage)
@interface AICFileStorage : NSObject <AICStorage>

@property (nonatomic, strong, nullable) id<AICCrypto> crypto;

- (instancetype _Nonnull)initWithFolder:(NSURL *_Nonnull)folderURL crypto:(id<AICCrypto> _Nullable)crypto;

- (NSURL *_Nonnull)urlForKey:(NSString *_Nonnull)key;

+ (NSURL *_Nullable)applicationSupportDirectoryURL;
+ (NSURL *_Nullable)cachesDirectoryURL;

@end
