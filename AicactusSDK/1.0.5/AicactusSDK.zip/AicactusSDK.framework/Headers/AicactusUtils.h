#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

// Logging

void AicactusShowDebugLogs(BOOL showDebugLogs);
void AICLog(NSString *format, ...);

NS_ASSUME_NONNULL_END
