#import <Foundation/Foundation.h>
#import "AICIdentifyPayload.h"
#import "AICTrackPayload.h"
#import "AICScreenPayload.h"
#import "AICAliasPayload.h"
#import "AICIdentifyPayload.h"
#import "AICGroupPayload.h"
#import "AICContext.h"

NS_ASSUME_NONNULL_BEGIN

NS_SWIFT_NAME(Integration)
@protocol AICIntegration <NSObject>

@optional
// Identify will be called when the user calls either of the following:
// 1. [[Aicactus sharedInstance] identify:someUserId];
// 2. [[Aicactus sharedInstance] identify:someUserId traits:someTraits];
// 3. [[Aicactus sharedInstance] identify:someUserId traits:someTraits options:someOptions];
// @see https://aicactus.com/docs/spec/identify/
- (void)identify:(AICIdentifyPayload *)payload;

// Track will be called when the user calls either of the following:
// 1. [[Aicactus sharedInstance] track:someEvent];
// 2. [[Aicactus sharedInstance] track:someEvent properties:someProperties];
// 3. [[Aicactus sharedInstance] track:someEvent properties:someProperties options:someOptions];
// @see https://aicactus.com/docs/spec/track/
- (void)track:(AICTrackPayload *)payload;

// Screen will be called when the user calls either of the following:
// 1. [[Aicactus sharedInstance] screen:someEvent];
// 2. [[Aicactus sharedInstance] screen:someEvent properties:someProperties];
// 3. [[Aicactus sharedInstance] screen:someEvent properties:someProperties options:someOptions];
// @see https://aicactus.com/docs/spec/screen/
- (void)screen:(AICScreenPayload *)payload;

// Group will be called when the user calls either of the following:
// 1. [[Aicactus sharedInstance] group:someGroupId];
// 2. [[Aicactus sharedInstance] group:someGroupId traits:];
// 3. [[Aicactus sharedInstance] group:someGroupId traits:someGroupTraits options:someOptions];
// @see https://aicactus.com/docs/spec/group/
- (void)group:(AICGroupPayload *)payload;

// Alias will be called when the user calls either of the following:
// 1. [[Aicactus sharedInstance] alias:someNewId];
// 2. [[Aicactus sharedInstance] alias:someNewId options:someOptions];
// @see https://aicactus.com/docs/spec/alias/
- (void)alias:(AICAliasPayload *)payload;

// Reset is invoked when the user logs out, and any data saved about the user should be cleared.
- (void)reset;

// Flush is invoked when any queued events should be uploaded.
- (void)flush;

// App Delegate Callbacks

// Callbacks for notifications changes.
// ------------------------------------
- (void)receivedRemoteNotification:(NSDictionary *)userInfo;
- (void)failedToRegisterForRemoteNotificationsWithError:(NSError *)error;
- (void)registeredForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken;
- (void)handleActionWithIdentifier:(NSString *)identifier forRemoteNotification:(NSDictionary *)userInfo;

// Callbacks for app state changes
// -------------------------------

- (void)applicationDidFinishLaunching:(NSNotification *)notification;
- (void)applicationDidEnterBackground;
- (void)applicationWillEnterForeground;
- (void)applicationWillTerminate;
- (void)applicationWillResignActive;
- (void)applicationDidBecomeActive;

- (void)continueUserActivity:(NSUserActivity *)activity;
- (void)openURL:(NSURL *)url options:(NSDictionary *)options;

@end

NS_ASSUME_NONNULL_END
