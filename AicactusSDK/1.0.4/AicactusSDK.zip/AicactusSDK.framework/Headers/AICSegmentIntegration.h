#import <Foundation/Foundation.h>
#import "AICIntegration.h"
#import "AICHTTPClient.h"
#import "AICStorage.h"

NS_ASSUME_NONNULL_BEGIN

extern NSString *const AICSegmentDidSendRequestNotification;
extern NSString *const AICSegmentRequestDidSucceedNotification;
extern NSString *const AICSegmentRequestDidFailNotification;

/**
 * Filenames of "Application Support" files where essential data is stored.
 */
extern NSString *const kAICUserIdFilename;
extern NSString *const kAICQueueFilename;
extern NSString *const kAICTraitsFilename;


NS_SWIFT_NAME(SegmentIntegration)
@interface AICSegmentIntegration : NSObject <AICIntegration>

- (id)initWithAnalytics:(Aicactus *)analytics httpClient:(AICHTTPClient *)httpClient fileStorage:(id<AICStorage>)fileStorage userDefaultsStorage:(id<AICStorage>)userDefaultsStorage;

@end

NS_ASSUME_NONNULL_END
